<?php
   session_start();
   
   define('DB_SERVER', 'localhost:3308');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'sa22521620');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      
      $myusername = mysqli_real_escape_string($db,$_POST['txtEmail']);
      $mypassword = mysqli_real_escape_string($db,$_POST['txtPassword']); 
      
      $sql = "SELECT name FROM tbluser WHERE Email = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      while($row = mysqli_fetch_array($result))
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
		  $_SESSION['username'] = $myusername;
         header("location: myAccount.php");
		 
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>   