-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jun 16, 2023 at 07:02 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sa22521620`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladvertisement`
--

DROP TABLE IF EXISTS `tbladvertisement`;
CREATE TABLE IF NOT EXISTS `tbladvertisement` (
  `AdvertisementID` int(11) NOT NULL AUTO_INCREMENT,
  `Productname` varchar(50) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `publish` int(11) NOT NULL,
  `category` varchar(20) NOT NULL,
  `imagepath` varchar(500) NOT NULL,
  `contactnumber` varchar(15) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`AdvertisementID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbladvertisement`
--

INSERT INTO `tbladvertisement` (`AdvertisementID`, `Productname`, `description`, `publish`, `category`, `imagepath`, `contactnumber`, `email`) VALUES
(2, 'Test', '123', 1, 'metal', 'uploads/7.jpg', '1', 'test@123.com'),
(15, 'Test', 'efs', 1, 'plastic', 'uploads/3.jpg', '12112111', 'sadadad@google.com'),
(10, 'Test', '123', 1, 'glass', 'uploads/5.jpg', '11231313131', 'test2@123.com'),
(12, 'Test', '123', 1, 'paper', 'uploads/2.jpg', '1242422242242', 'test3@123.com'),
(14, 'sdsd', 'Test', 1, 'paper', 'uploads/2.jpg', '12112111', 'test@123.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblinquiry`
--

DROP TABLE IF EXISTS `tblinquiry`;
CREATE TABLE IF NOT EXISTS `tblinquiry` (
  `IndquiryID` int(11) NOT NULL AUTO_INCREMENT,
  `inquiry` varchar(3000) NOT NULL,
  `date` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `advertisementID` int(11) NOT NULL,
  PRIMARY KEY (`IndquiryID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `Email` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contactnumber` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`Email`, `name`, `contactnumber`, `password`) VALUES
('test@123.com', 'dineth', '0767400025', 'dineth123'),
('123@456.com', 'a', '123', '0123456789'),
('sadadad@google.com', 'e', '0123456789', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
