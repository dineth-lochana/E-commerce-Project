
<?php session_start();
    
        
//Connect to the Database
$con = mysqli_connect("localhost","root","","sa22521620","3308");

//Error Handling
if (!$con)
{
   die("Sorry we are facing a technical issue."); 
}

//SQL Query
$sql = "DELETE FROM `tbladvertisement` WHERE `tbladvertisement`.`AdvertisementID` =".$_SESSION["id"].";";
    
mysqli_query($con,$sql);
             
//Execute the Code for the Site
if(mysqli_query($con,$sql)) 
{
    echo "Advertisement uploaded sucessfully.";
}
else
{
    echo "Something is wrong, please try again.";
}
    

header("location: ViewMyAdvertisements.php");
    
    
    
?>