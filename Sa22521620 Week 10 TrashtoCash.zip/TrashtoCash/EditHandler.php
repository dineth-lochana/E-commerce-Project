
<?php session_start();
    
if(isset($_POST["btnSubmit"]))
{          
    
//Read the Values user has given and assign to variables.

$description = $_POST["txtDescription"];
$productname = $_POST["txtTitle"];
$category = $_POST["category"];
$contact = $_POST["txtContactNumber"];   
 
    
if(isset($_POST["chkPublish"]))
{
    $status = 1;
}
else
{
    $status = 0;
}
    

if(!file_exists($_FILES["imageFile"]["tmp_name"]) || !is_uploaded_file($_FILES["imageFile"]["tmp_name"]))
   {
       $image = $_SESSION["imagepath"];
   }
   else
   {
       
       //Deal with the uploaded image    
$image = "uploads/".basename($_FILES["imageFile"]["name"]);
move_uploaded_file($_FILES["imageFile"]["tmp_name"],$image);  
       
   }
               
    
    
  
        
//Connect to the Database
$con = mysqli_connect("localhost","root","","sa22521620","3308");

//Error Handling
if (!$con)
{
   die("Sorry we are facing a technical issue."); 
}

//SQL Query
$sql = "UPDATE `tbladvertisement` SET `Productname` = '".$productname."', `description` = '".$description."', `publish` = '".$status."', `category` = '".$category."', `imagepath` = '".$image."', `contactnumber` = '".$contact."' WHERE `tbladvertisement`.`AdvertisementID` = ".$_SESSION["id"].";";
    
mysqli_query($con,$sql);
             
//Execute the Code for the Site
if(mysqli_query($con,$sql)) 
{
    echo "Advertisement uploaded sucessfully.";
}
else
{
    echo "Something is wrong, please try again.";
}
    

header("location: ViewMyAdvertisements.php");
    
}
    
    
?>