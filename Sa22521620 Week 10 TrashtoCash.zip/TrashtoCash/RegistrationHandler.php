<?php session_start();

if(isset($_POST["btnSubmit"]))
{          
    
//Read the Values user has given and assign to variables.
$password = $_POST["txtPassword"];
$email = $_POST["txtEmail"];
$name = $_POST["txtName"];
$contact = $_POST["txtContactNo"];   
 
//Connect to the Database
$con = mysqli_connect("localhost","root","","sa22521620","3308");

//Error Handling
if (!$con)
{
   die("Sorry we are facing a technical issue."); 
}

//SQL Query
$sql = "INSERT INTO `tbluser`(`Email`, `name`, `contactnumber`, `password`) VALUES ('".$email."','".$name."','".$contact."','".$password."')";
    
//Execute the Code for the Site
mysqli_query($con,$sql) ;
 
    
header("location: login.php");
    
}
?>    